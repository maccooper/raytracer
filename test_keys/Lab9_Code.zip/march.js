"use strict";

var gl;
var points;

// Current time
var timeLocation;

//The aspect ratio as a float
var aspectRatio;
var aspectRatioLocation;

// Half of the fragment size in screen coordinates, used for antialiasing
var halfScreenFragSize;
var halfScreenFragSizeLocation;


window.onload = function init()
{
    var canvas = document.getElementById( "gl-canvas" );

    gl = canvas.getContext('webgl2');
    if (!gl) { alert( "WebGL 2.0 isn't available" ); }

    // Four Vertices
    var vertices = [
        vec2( -1, -1 ),
        vec2(  -1,  1 ),
        vec2(  1, 1 ),
        vec2( 1, -1)
    ];

    //
    //  Configure WebGL
    //
    gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 1.0, 1.0, 1.0, 1.0 );

	//  Load shaders and initialize attribute buffers
	var program = initShaders( gl, "vertex-shader", "fragment-shader" );
	gl.useProgram( program );

	// Load the data into the GPU
	var bufferId = gl.createBuffer();
	gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
	gl.bufferData( gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW );

	// Associate out shader variable with our data buffer
	var aPosition = gl.getAttribLocation( program, "aPosition" );
	gl.vertexAttribPointer( aPosition, 2, gl.FLOAT, false, 0, 0 );
	gl.enableVertexAttribArray(aPosition);
	
	// Get time location in compiled shader program
	timeLocation = gl.getUniformLocation(program, "time");
	
	// Get screen variables in compiled shader program
	aspectRatioLocation = gl.getUniformLocation(program, "aspect_ratio");
	halfScreenFragSizeLocation = gl.getUniformLocation(program, "half_screen_frag_size");
	
	// Precompute screen variables, we're assuming these dont change but you can put them in a callback and dynamically resize and update
	
	// Aspect ratio is used to undo the distortion caused when tracing non uniform width and height windows 
	// For example, this way you can have wide aspect ratio without widening the rendered scene (see frag shader for how it is used)
	aspectRatio = canvas.width / canvas.height;
	
	// First 1.0 / canvas.width is the size of a fragment in the screen coordinates 0 to 1.
	// Half of that is half the size of a fragment. We are going to use this to antialias in the fragment shader
	halfScreenFragSize = vec2( 1.0 / (2.0 * canvas.width), 1.0 / (2.0 * canvas.height) );
	
    render();
};


function render(timestamp) {
	// Set the uniforms
	gl.uniform1f(timeLocation, timestamp/1000.0 );
	gl.uniform1f(aspectRatioLocation, aspectRatio );
	gl.uniform2fv(halfScreenFragSizeLocation, halfScreenFragSize );

	// Draw our screen filling triangles (just a quad)
    gl.clear( gl.COLOR_BUFFER_BIT );
    gl.drawArrays( gl.TRIANGLE_FAN, 0, 4 );
	
	window.requestAnimFrame(render);
}
